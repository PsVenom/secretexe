from flask import Flask, request, jsonify, render_template
from flask_cors import CORS
import os
import json
import subprocess
from model.chat import chat
from dotenv import load_dotenv
from tkinter import Tk, filedialog
# Load environment variables from .env file
load_dotenv()

# Function to open a folder selection dialog and store the selected directory in the .env file
def select_directory():
    root = Tk()
    root.withdraw()  # Hide the root window
    root.attributes('-topmost', True)  # Bring the file dialog to the front
    selected_directory = filedialog.askdirectory()  # Open directory selection dialog
    root.destroy()  # Destroy the root window after selection

    if selected_directory:  # If a directory is selected
        # Append the selected directory to the existing .env file
        with open(".env", "a") as f:  # Open the file in append mode ('a')
            f.write(f'LAGRANGE_DIR= "{selected_directory}"\n')
        print(f"Selected root directory: {selected_directory}")
        return selected_directory
    else:
        print("No directory selected. Exiting.")
        exit(1)

# Check if the directory is already set in the .env file
lagrange_dir = os.getenv("LAGRANGE_DIR")

# If no valid directory is set, prompt the user to select one
if not lagrange_dir or not os.path.exists(lagrange_dir.strip(' "')):
    print("LAGRANGE_DIR not found in the .env file or invalid. Please select a directory.")
    lagrange_dir = select_directory()

# Ensure the LAGRANGE_DIR path is clean (removes any accidental quotes around the path)
lagrange_dir = lagrange_dir.strip(' "')

app = Flask(__name__)
CORS(app)  # Enable CORS on all routes

# Ensure the selected directory exists
if not os.path.isdir(lagrange_dir):
    print(f'Creating Lagrange directory at {lagrange_dir}')
    os.mkdir(lagrange_dir)
else:
    print(f'Lagrange directory exists at {lagrange_dir}......continuing')

# Create media directory inside the root directory
media_dir = os.path.join(lagrange_dir, 'media')
if not os.path.isdir(media_dir):
    os.mkdir(media_dir)
    print('Creating media directory inside Lagrange directory')
else:
    print('Media directory exists......continuing')

# The rest of your Flask server routes
def create_file_node(file_path):
    return {
        "name": os.path.basename(file_path),
        "path": file_path,
        "children": []
    }

def create_directory_node(dir_path):
    node = create_file_node(dir_path)
    children = []
    for child_name in os.listdir(dir_path):
        if child_name.startswith('.'):
            continue
        child_path = os.path.join(dir_path, child_name)
        if os.path.isdir(child_path):
            children.append(create_directory_node(child_path))
        else:
            children.append(create_file_node(child_path))
    node["children"] = children
    return node

def update_file_tree(directory_path=lagrange_dir, output_file=os.path.join(lagrange_dir, "file_tree.json")):
    root_node = create_directory_node(directory_path)
    with open(output_file, "w") as json_file:
        json.dump(root_node, json_file, indent=4)

@app.route('/')
def page():
    return render_template('index.html')

@app.route('/send_string', methods=['GET'])
def send_string():
    global last_response
    if last_response:
        return last_response
    else:
        return "No message processed yet!"
    
@app.route('/input_t', methods=['POST'])
def input_t():
    global last_response
    if request.is_json:
        data = request.get_json()
        conversation = data.get('conversation', [])
        session_id = data.get('session_id', 'default_session')
        model = data.get('model', 'claude-3-5-sonnet-20240620')  # Get model from request
        last_response = chat(data['message'], data.get('fileList', []), conversation, session_id, model)
        # print(last_response)
        return last_response, 200
    return "Invalid data", 400

@app.route('/input_m', methods=['POST'])
def input_m():
    if 'document' not in request.files:
        return "No document part", 400
    file = request.files['document']
    if file.filename == '':
        return "No selected file", 400
    if file:
        filename = file.filename
        print(filename)
        file.save(os.path.join(media_dir, filename))
        return f"Document {filename} received and saved.", 200
    return "Invalid data", 400

@app.route('/open-file', methods=['POST'])
def open_file():
    data = request.get_json()
    file_path = data.get('filePath')
    if file_path:
        try:
            path = os.path.join(lagrange_dir, file_path)
            subprocess.run(['open', path])
            return jsonify({'message': f'File "{file_path}" opened successfully.'}), 200
        except Exception as e:
            return jsonify({'error': f'Failed to open file: {e}'}), 500
    else:
        return jsonify({'error': 'File path not provided.'}), 400

@app.route('/get-json', methods=['GET'])
def read_json():
    try:
        update_file_tree()
        json_file_path = os.path.join(lagrange_dir, 'file_tree.json')
        with open(json_file_path, 'r') as file:
            json_data = json.load(file)
        return jsonify(json_data)
    except Exception as e:
        print(e)
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8080, debug = True)